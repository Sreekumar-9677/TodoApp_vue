const firebaseConfig = {
    apiKey: "AIzaSyAIO4BmokeMYY3a_zXlmhYVpkJChDc24Mc",
    authDomain: "sample1-bbafb.firebaseapp.com",
    projectId: "sample1-bbafb",
    storageBucket: "sample1-bbafb.appspot.com",
    messagingSenderId: "1097378291487",
    appId: "1:1097378291487:web:8ea2b2643a0edb70991a2a"
  };