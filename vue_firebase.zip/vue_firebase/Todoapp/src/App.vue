

<script setup>

import { ref, onMounted } from 'vue-demi';


const title = ref('Todo List');
const statusFilter = ref('');
const newNote = ref('');

const addNewNote = () => {

};

onMounted(() => {
  
});
</script>

<template>
  <div>
    <h2>{{ title }}</h2>

    <div class="mb-3">
      <label for="statusFilter">Filter by Status:</label>
      <select v-model="statusFilter" id="statusFilter" class="form-select">
        <option value="">All</option>
        <option value="pending">Pending</option>
        <option value="completed">Completed</option>
      </select>
    </div>

    <input v-model="newNote" class="form-control mb-3" placeholder="Add a new note" />&nbsp;
    <button @click="addNewNote" class="btn btn-success">Add Note</button>

    <table class="table mt-3">
   
    </table>
  </div>
</template>


