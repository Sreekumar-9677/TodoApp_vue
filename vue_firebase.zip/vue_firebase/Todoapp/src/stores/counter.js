// counter.js
import { defineStore } from 'pinia';

export const useTodoStore = defineStore('todo', {
  state: () => ({
    title: 'Todo List',
    notes: [],
    newNote: '',
    editingNote: null,
    editedDescription: '',
    statusFilter: '',
  }),

  actions: {
    async refreshData(db) {
      this.notes = [];
      const querySnapshot = await getDocs(collection(db, 'notes'));
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        this.notes.push({
          id: doc.id,
          description: data.description,
          status: data.status,
          createdAt: data.createdAt.toDate().toLocaleString(),
          updatedAt: data.updatedAt.toDate().toLocaleString(),
        });
      });
    },

    async addNewNote(db) {
      const newNoteDescription = this.newNote.trim();
      if (newNoteDescription !== '') {
        await addDoc(collection(db, 'notes'), { description: newNoteDescription, status: 'pending', createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
        this.newNote = '';
        await this.refreshData(db);
      }
    },

    toggleEditMode(note) {
      this.editingNote = this.editingNote === note ? null : note;
      this.editedDescription = this.editingNote ? this.editingNote.description : '';
    },

    async saveEditedNote(db) {
      if (this.editingNote && this.editedDescription.trim() !== '') {
        await updateDoc(doc(db, 'notes', this.editingNote.id), { description: this.editedDescription.trim(), updatedAt: serverTimestamp() });
        this.toggleEditMode(this.editingNote);
        await this.refreshData(db);
      }
    },

    async deleteNote(db, id) {
      await deleteDoc(doc(db, 'notes', id));
      await this.refreshData(db);
    },

    async updateNoteStatus(db, note) {
      const newStatus = note.completed ? 'completed' : 'pending';
      await updateDoc(doc(db, 'notes', note.id), { status: newStatus, updatedAt: serverTimestamp() });
      await this.refreshData(db);
    },
  },
});
